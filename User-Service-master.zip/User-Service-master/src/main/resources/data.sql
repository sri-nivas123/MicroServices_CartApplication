insert into user(id,name,address) values(100,'Noel', 'Hyderabad');
insert into user(id,name,address) values(101,'noel', 'Secunderabad');
insert into user(id,name,address) values(102,'ganesh', 'Hyderabad');
insert into user(id,name,address) values(103,'Noel', 'Hyderabad');