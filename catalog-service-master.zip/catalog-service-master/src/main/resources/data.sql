insert into product(id,name,price) values(10,'Laptop',999);
insert into product(id,name,price) values(20,'Mobile',888);
insert into product(id,name,price) values(30,'Watch',777);
